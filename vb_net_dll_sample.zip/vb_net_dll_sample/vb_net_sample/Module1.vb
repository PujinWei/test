﻿Imports KvHostlinkLib

Module Module1
    Sub Main()
        '' 時間測定用
        Dim sw As New Stopwatch

        Dim errCode As Integer

        ' バージョンの確認
        Dim version As Integer = KvHostlinkLib.KvHostlinkLib.version
        Console.WriteLine("KvHostLinkLib：version" & version)

        ' 初期化 socketNum:ソケット数 socketType:ソケット種類(TCP or UDP)
        ' TCP使用時
        Dim KVSockets As New KvHostlinkLib.KvHostlinkLib(socketNum:=9, timeOutMs:=5000, socketType:=KvHostlinkLib.KvHostlinkLib.socketType.tcp)
        ' UDP仕様時
        ' Dim KVSockets As New KvHostlinkLib.KvHostlinkLib(timeOutMs:=5000, socketType:=KvHostlinkLib.KvHostlinkLib.socketType.udp)

        ' 読出、書込用バイト配列
        Dim devBy(16384) As Byte

        ' 全ソケットでコネクションを張る
        errCode = KVSockets.ConnectAll(ipAddress:="192.168.0.10", port:=8501)
        If errCode <> 0 Then
            Console.WriteLine(KVSockets.ErrMsg(errCode))
            Console.ReadKey()
            Return
        End If
        Console.WriteLine("接続完了")

        ' ZF8000~からバイト読出
        sw.Restart()
        errCode = KVSockets.ReadDevices("ZF", 0, 16384, devBy)
        sw.Stop()
        Console.WriteLine("16384バイトの読出:" & sw.ElapsedMilliseconds & "ms")
        If errCode <> 0 Then
            Console.WriteLine(KVSockets.ErrMsg(errCode))
            Console.ReadKey()
            Return
        End If

        ' ZF8000に入っている値を対応する型に変換して表示
        Dim displayNum = 8000
        Dim rByteIndex = displayNum * 2
        Console.Write("UINT  :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToUInt16(devBy, rByteIndex))
        Console.Write("INT   :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToInt16(devBy, rByteIndex))
        Console.Write("DUINT :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToUInt32(devBy, rByteIndex))
        Console.Write("DINT  :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToInt32(devBy, rByteIndex))
        Console.Write("REAL  :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToSingle(devBy, rByteIndex))
        Console.Write("LREAL :")
        Console.WriteLine("ZF" & displayNum & ":" & BitConverter.ToDouble(devBy, rByteIndex))
        Console.Write("STRING:")
        Console.WriteLine("ZF" & displayNum & ":" & KvHostlinkLib.KvHostlinkLib.ByteToString(devBy, rByteIndex, 9))

        ' EM200を先頭に8バイトずつオフセットして各型の値をセット
        Dim buffByte(30) As Byte

        ' EM200:UINT
        Dim writeNo = 200
        Dim wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(100, UInt16))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 2)
        ' EM204:INT
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(-200, Int16))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 2)
        ' EM208:DUINT
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(100000, UInt32))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 4)
        ' EM212:DINT
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(-100000, Int32))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 4)
        ' EM216:REAL
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(-12.34, Single))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 4)
        ' EM220:LREAL
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = BitConverter.GetBytes(CType(-12345.6789, Double))
        Array.Copy(buffByte, 0, devBy, wByteIndex, 8)
        ' EM224~:STRING
        writeNo += 4
        wByteIndex = writeNo * 2
        buffByte = KvHostlinkLib.KvHostlinkLib.StringToByte("メンテナンス")
        Array.Copy(buffByte, 0, devBy, wByteIndex, buffByte.Length)

        ' バイト書込
        sw.Restart()
        errCode = KVSockets.WriteDevices("EM", 0, 16384, devBy)
        sw.Stop()
        Console.WriteLine("16384バイトの書込:" & sw.ElapsedMilliseconds & "ms")
        If errCode <> 0 Then
            Console.WriteLine(KVSockets.ErrMsg(errCode))
            Console.ReadKey()
            Return
        End If

        ' 全コネクションでソケットを閉じる
        KVSockets.DisConnectAll()

        ' リソースの開放
        KVSockets.Dispose()

        Console.ReadKey()
    End Sub

End Module

