
'use strict';

class Normalizer{
	normalize(){
		throw new Error('not implemented');
	}
}

module.exports = Normalizer;
