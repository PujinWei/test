﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // 時間測定用
            Stopwatch sw = new Stopwatch();

            int errCode;

            // バージョンの確認
            int version = KvHostlinkLib.KvHostlinkLib.version;
            Console.WriteLine("KvHostLinkLib：version" + version);

            // 初期化 socketNum:ソケット数 socketType:ソケット種類(TCP or UDP)
            // TCP使用時
            var KVSockets = new KvHostlinkLib.KvHostlinkLib(socketNum: 9, timeOutMs: 5000, socketType: (int)KvHostlinkLib.KvHostlinkLib.socketType.tcp);
            // UDP仕様時
            // var KVSockets = new KvHostlinkLib.KvHostlinkLib(timeOutMs: 5000, socketType: (int)KvHostlinkLib.KvHostlinkLib.socketType.udp);

            // 読出、書込用バイト配列
            byte[] devBy = new byte[16384];

            // 全ソケットでコネクションを張る
            errCode = KVSockets.ConnectAll(ipAddress: "192.168.0.10", port: 8501);
            if (errCode != 0)
            {
                Console.WriteLine(KVSockets.ErrMsg(errCode));
                Console.ReadKey();
                return;
            }
            Console.WriteLine("接続完了");

            // ZF8000からバイト読出
            sw.Restart();
            errCode = KVSockets.ReadDevices("ZF", 0, 16384, ref devBy);
            sw.Stop();
            Console.WriteLine("16384バイトの読出:" + sw.ElapsedMilliseconds + "ms");
            if (errCode != 0)
            {
                Console.WriteLine(KVSockets.ErrMsg(errCode));
                Console.ReadKey();
                return;
            }
            Thread.Sleep(3000);

            // ZF8000に入っている値を対応する型に変換して表示
            int displayNum = 8000;
            int rByteIndex = displayNum * 2;
            Console.Write("UINT  :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToUInt16(devBy, rByteIndex));
            Console.Write("INT   :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToInt16(devBy, rByteIndex));
            Console.Write("DUINT :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToUInt32(devBy, rByteIndex));
            Console.Write("DINT  :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToInt32(devBy, rByteIndex));
            Console.Write("REAL  :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToSingle(devBy, rByteIndex));
            Console.Write("LREAL :");
            Console.WriteLine("ZF" + displayNum + ":" + BitConverter.ToDouble(devBy, rByteIndex));
            Console.Write("STRING:");
            Console.WriteLine("ZF" + displayNum + ":" + KvHostlinkLib.KvHostlinkLib.ByteToString(devBy, rByteIndex, 9));

            // EM200を先頭に8バイトずつオフセットして各型の値をセット
            byte[] buffByte = new byte[30];

            // EM200:UINT
            int writeNo = 200;
            int wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((ushort)100);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 2);
            // EM204:INT;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((short)-200);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 2);
            // EM208:DUINT;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((uint)100000);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 4);
            // EM212:DINT;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((int)-100000);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 4);
            // EM216:REAL;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((float)-12.34);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 4);
            // EM220:LREAL;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = BitConverter.GetBytes((double)-12345.6789);
            Array.Copy(buffByte, 0, devBy, wByteIndex, 8);
            // EM224~:STRING;
            writeNo += 4;
            wByteIndex = writeNo * 2;
            buffByte = KvHostlinkLib.KvHostlinkLib.StringToByte("メンテナンス");
            Array.Copy(buffByte, 0, devBy, wByteIndex, buffByte.Length);

            // バイト書込
            sw.Restart();
            errCode = KVSockets.WriteDevices("EM", 0, 16384, ref devBy);
            sw.Stop();

            // 
            Console.WriteLine("16384バイトの書込:" + sw.ElapsedMilliseconds + "ms");
            if (errCode != 0)
            {
                Console.WriteLine(KVSockets.ErrMsg(errCode));
                Console.ReadKey();
                return;
            }

            // 全コネクションでソケットを閉じる
            KVSockets.DisConnectAll();

            // リソースの解放
            KVSockets.Dispose();

            Console.ReadKey();
            return;
        }
    }
}
